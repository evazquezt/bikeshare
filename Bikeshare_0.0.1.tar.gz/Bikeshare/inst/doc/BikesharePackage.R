### R code from vignette source 'BikesharePackage.Rnw'

###################################################
### code chunk number 1: BikesharePackage.Rnw:27-34
###################################################
library(Bikeshare)
## Load station data.
stations = readStationData(system.file("extData/bikeStations.xml",
                    package="Bikeshare"),.cities()$WAS)
## Load trip data
bd = readTripData(system.file("extData/2010-4th-quarter.csv", 
                    package="Bikeshare"), .cities()$WAS, stations)


###################################################
### code chunk number 2: BikesharePackage.Rnw:40-41
###################################################
plotStations(stations)


###################################################
### code chunk number 3: BikesharePackage.Rnw:46-53
###################################################
## Uses best biking path result from Google Maps API
#distances <- as.data.frame(t(getDistance(stations,fromSubset="stationId==31200",
#                        mode="bicycling")))
#closeStations <- (distances[,1] <= 3) | (rownames(distances)=="31200")
distances <- 20*runif(313)  ## until I can do queries again :\
closeStations <- distances <= 3
plotBubbles(bd, stationSubset=closeStations,zoom=14,alpha=.5)


###################################################
### code chunk number 4: BikesharePackage.Rnw:58-59
###################################################
plotTrips(bd,stationSubset=closeStations,zoom=14,alpha=.5)


###################################################
### code chunk number 5: BikesharePackage.Rnw:64-78
###################################################
## convert the station data object to a dataframe
stationDF <- makeStationDataFrame(stations)
## Find total visits to each station
totalVisits <- getTotalVisits(bd)
names(totalVisits)[1] <- "stationId"

## Merge total visits data into stationDF
stationDF <- merge(stationDF, totalVisits)

## Run a simple linear regression of station visits on number of bikes
model <- lm(visits ~ numBikes, data=stationDF)
summary(model)
qplot(numBikes, visits, data=stationDF) + 
  geom_abline(intercept=coef(model)[1],slope=coef(model)[2])


###################################################
### code chunk number 6: BikesharePackage.Rnw:86-110
###################################################
library(geosphere)
stationDF <- subset(makeStationDataFrame(stations),closeStations)
distMat <- distm(stationDF[,c("long","lat")])/1000 + 1e10*diag(dim(stationDF)[1])
closest <- apply(distMat,1,which.min)
stationDF$closestIndex <- closest

## Add a column to stationDF containing distance to the nearest station
index <- matrix(c(1:dim(distMat)[1],closest),ncol=2)
stationDF$closestStation <- distMat[index]

## Add a column to stationDF containing number of bikes at nearest station
stationDF$closestNumBikes <- stationDF$numBikes[closest]

## Add a column to stationDF containing total visits to station and total visits to closest station
totalVisits <- getTotalVisits(bd,stationSubset=closeStations)
names(totalVisits)[1] <- "stationId"
stationDF <- merge(stationDF,totalVisits)
stationDF$closestVisits <- stationDF$visits[closest]

## Try some simple linear models
model <- lm(visits ~ closestStation + closestNumBikes + closestVisits + numBikes,data=stationDF)
model <- lm(visits ~ closestVisits + closestStation,data=stationDF)
model <- lm(visits ~ closestStation,data=stationDF) ## something like this? easy...
summary(model)


###################################################
### code chunk number 7: BikesharePackage.Rnw:115-123
###################################################
stationDF <- makeStationDataFrame(stations)
stationDF$ranks <- data.frame(stationSimRank(bd,31200))[,1]

## visualize results using a bubble plot weighted by rank
center <- c(mean(stationDF$long),mean(stationDF$lat))
map <- get_map(location=center,zoom=13,scale = "auto",source="google")
b <- ggmap(map)
b + geom_point(data=stationDF, aes(x=long,y=lat,size=ranks),colour="red",alpha=.5)


