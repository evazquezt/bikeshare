### R code from vignette source 'BikesharePackage.Rnw'

