### R code from vignette source 'BikesharePackage.Rnw'

###################################################
### code chunk number 1: BikesharePackage.Rnw:35-42
###################################################
library(Bikeshare)
## Load station data.
stations = readStationData(system.file("extData/bikeStations.xml",
                    package="Bikeshare"),.cities()$WAS)
## Load trip data
bd = readTripData(system.file("extData/2010-4th-quarter.csv", 
                    package="Bikeshare"), .cities()$WAS, stations)


###################################################
### code chunk number 2: BikesharePackage.Rnw:49-50
###################################################
plotStations(stations)


###################################################
### code chunk number 3: BikesharePackage.Rnw:54-59
###################################################
## Uses best biking path result from Google Maps API
distances <- as.data.frame(t(getDistance(stations,fromSubset="stationId==31200",
                        mode="bicycling")))
closeStations <- (distances[,1] <= 3) | (rownames(distances)=="31200")
plotTrips(bd,stationSubset=closeStations,zoom=14,alpha=.5)


###################################################
### code chunk number 4: BikesharePackage.Rnw:64-76
###################################################
## convert the station data object to a dataframe
stationDF <- makeStationDataFrame(stations)
## Find total visits to each station
totalVisits <- getTotalVisits(bd)
names(totalVisits)[1] <- "stationId"

## Merge total visits data into stationDF
stationDF <- merge(stationDF, totalVisits)

## Run a simple linear regression of station visits on number of bikes
model <- lm(visits ~ numBikes, data=stationDF)
summary(model)


###################################################
### code chunk number 5: BikesharePackage.Rnw:80-82
###################################################
qplot(numBikes, visits, data=stationDF) + 
  geom_abline(intercept=coef(model)[1],slope=coef(model)[2])


###################################################
### code chunk number 6: BikesharePackage.Rnw:86-88
###################################################
stationDF <- makeStationDataFrame(stations)
stationDF$ranks <- data.frame(stationSimRank(bd,31200))[,1]


###################################################
### code chunk number 7: BikesharePackage.Rnw:91-95
###################################################
## visualize results using a bubble plot weighted by rank
center <- c(mean(stationDF$long),mean(stationDF$lat))
map <- get_map(location=center,zoom=13,scale = "auto",source="google")
ggmap(map) + geom_point(data=stationDF, aes(x=long,y=lat,size=ranks),colour="red",alpha=.5)


