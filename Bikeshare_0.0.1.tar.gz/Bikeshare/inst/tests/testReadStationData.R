expect_true(length(stations) > 0)
expect_true(nrow(makeStationDataFrame(stations)) > 0)
